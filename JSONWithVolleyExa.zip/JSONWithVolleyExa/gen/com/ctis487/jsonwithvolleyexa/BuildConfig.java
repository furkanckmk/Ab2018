/** Automatically generated file. DO NOT MODIFY */
package com.ctis487.jsonwithvolleyexa;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}