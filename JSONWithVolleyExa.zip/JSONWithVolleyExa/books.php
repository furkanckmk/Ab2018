<?php

$key = $_REQUEST["arama"];

echo $key;
$notfound = array("books"=>array(array( 
		"name"=>"Not Found",
		"author"=> "Not Found",
		"year"=> "Not Found",
		"img"=>"Not Found" 
		)));

$ar = array("books"=>array(array( 
		"name"=>"LOTR: Two Towers",
		"author"=> "J.R.R. Tolkien",
		"year"=> "1982",
		"img"=>"twotowers.jpg" 
	),
	array( 
		"name"=> "Hunger Games",
		"author"=> "Suzanne Collins",
		"year"=> "2010",
		"img"=>"hungergames.jpg" ),
	array( 
		"name"=> "Alchemist",
		"author"=> "Paulo Coelho",
		"year"=> "1993",
		"img"=>"alchemist.jpg" 
		)
		));

	if(isset($key)){
		$result = array();		
		$i=0;
		foreach($ar["books"] as $books) {
			
			if ($books["year"]== $key) {
			   	$result["books"][$i] = $books;
				$i++;
				echo "year";
    	    }
			else if (strpos(strtolower($books["name"]), strtolower($key)) !== false) {
			   	$result["books"][$i] = $books;
				$i++;
				echo "name";
    	    }
			else if (strpos(strtolower($books["author"]), strtolower($key)) !== false) {
			   	$result["books"][$i] = $books;
				$i++;
				echo "author";
    	    }
			
	 	}
		if(count($result)> 0)
			echo json_encode($result);
		else
			echo json_encode($notfound);
	}
	else
		echo json_encode($ar);

?>